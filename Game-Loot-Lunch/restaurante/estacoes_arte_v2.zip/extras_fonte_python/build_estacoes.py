import os, shutil
from estacoes import *
OUT = '/home/claude/outest'; RES = OUT + '/restaurante/cozinha/estacoes/arte_v2'
shutil.rmtree(OUT, ignore_errors=True); os.makedirs(RES + '/previews')
ANIMS = {
 'cogumelo_pe': [('idle', cogumelo_idle(), True, 6), ('corte', cogumelo_corte(), False, 12), ('regenerando', cogumelo_regen(), False, 1.6)],
 'raiz_espeto': [('idle', raiz_idle(), True, 6), ('corte', raiz_corte(), False, 12), ('regenerando', raiz_regen(), False, 2.67)],
}
for nome, anims in ANIMS.items():
    anims = anims + [('vazio', [anims[1][1][-1]], False, 1)]
    cols = max(len(f) for _, f, _, _ in anims)
    sheet = Image.new('RGBA', (cols * FW, len(anims) * FH), (0, 0, 0, 0))
    for r, (_, frames, _, _) in enumerate(anims):
        for c, f in enumerate(frames): sheet.alpha_composite(f, (c * FW, r * FH))
    sheet.save(f'{RES}/{nome}.png')
    # SpriteFrames
    subs, anim_txt, n = [], [], 0
    for r, (an, frames, loop, fps) in enumerate(anims):
        fl = []
        for c in range(len(frames)):
            n += 1; sid = f'AtlasTexture_{nome}_{n}'
            subs.append(f'[sub_resource type="AtlasTexture" id="{sid}"]\natlas = ExtResource("1_tex")\nregion = Rect2({c * FW}, {r * FH}, {FW}, {FH})\n')
            fl.append(f'{{\n"duration": 1.0,\n"texture": SubResource("{sid}")\n}}')
        anim_txt.append('{\n"frames": [' + ', '.join(fl) + f'],\n"loop": {"true" if loop else "false"},\n"name": &"{an}",\n"speed": {fps}\n}}')
    tres = f'[gd_resource type="SpriteFrames" load_steps={n + 2} format=3]\n\n[ext_resource type="Texture2D" path="res://restaurante/cozinha/estacoes/arte_v2/{nome}.png" id="1_tex"]\n\n' + '\n'.join(subs) + '\n[resource]\nanimations = [' + ', '.join(anim_txt) + ']\n'
    open(f'{RES}/{nome}_frames.tres', 'w').write(tres)
    # GIFs de preview (x4)
    for an, frames, loop, fps in anims:
        if len(frames) < 2: continue
        gf = []
        for f in frames + ([frames[-1]] * 4 if not loop else []):
            bg = Image.new('RGBA', (FW, FH), (74, 64, 84, 255)); bg.alpha_composite(f); gf.append(bg.resize((FW * 4, FH * 4), Image.NEAREST).convert('P', palette=Image.ADAPTIVE))
        dur = int(1000 / max(fps, 6)) if an != 'regenerando' else 220
        gf[0].save(f'{RES}/previews/{nome}_{an}.gif', save_all=True, append_images=gf[1:], duration=dur, loop=0)
mesa_carne().save(RES + '/mesa_carne.png'); mesa_corte().save(RES + '/mesa_corte.png')
# folha de visao geral
rows = [f for n in ANIMS for (_, f, _, _) in ANIMS[n]]
ov = Image.new('RGBA', (8 * FW, len(rows) * FH + 36), (74, 64, 84, 255))
for i, f in enumerate(rows): ov.alpha_composite(strip(f), (0, i * FH))
ov.alpha_composite(mesa_carne(), (0, len(rows) * FH + 2)); ov.alpha_composite(mesa_corte(), (36, len(rows) * FH + 2))
ov.resize((ov.width * 4, ov.height * 4), Image.NEAREST).save(RES + '/previews/estacoes_v2_x4.png')
print('ok')
