from base import *
# ---------- paleta: chef + churrasqueira + tons do test_room ----------
O = (43, 29, 14)
PED = [(206, 214, 230), (164, 178, 206), (128, 144, 180), (96, 108, 148), (66, 74, 110), (44, 46, 72)]   # pedra azul
LAJ = [(244, 232, 210), (226, 210, 184), (204, 184, 156), (172, 150, 124), (138, 116, 98)]            # lajota creme
TER = [(232, 170, 118), (196, 122, 86), (160, 92, 68), (118, 62, 52), (84, 44, 40)]                  # lajota terracota
MAD = [(222, 178, 126), (190, 146, 102), (152, 108, 76), (116, 78, 58), (82, 54, 44)]                # madeira
ROX = [(206, 190, 255), (150, 120, 236), (110, 80, 204), (74, 48, 144), (42, 24, 78)]
FOGO = [(255, 228, 140), (246, 164, 60), (226, 100, 34), (160, 44, 30)]
CRE = [(252, 248, 236), (232, 224, 200), (212, 200, 172), (186, 172, 146), (156, 140, 120)]
GRA = [(178, 214, 116), (142, 190, 92), (112, 162, 78), (86, 132, 68), (62, 100, 60)]
TERRA = [(176, 140, 104), (150, 116, 86), (124, 94, 70), (96, 72, 56)]
VERM = [(220, 86, 90), (180, 52, 64), (130, 34, 48)]
VERDE = [(126, 176, 92), (84, 132, 66), (56, 92, 52)]

def lajota(pal, seed, grande=False):
    """lajotas arredondadas (como no test_room) mas com luz suave e rejunte quente"""
    im = new(); rnd = random.Random(seed)
    rect(im, 0, 0, 15, 15, pal[4])
    blocos = [(0, 0, 15, 15)] if grande else [(0, 0, 7, 7), (8, 0, 15, 7), (0, 8, 7, 15), (8, 8, 15, 15)]
    if not grande and seed % 3 == 1: blocos = [(0, 0, 7, 15), (8, 0, 15, 7), (8, 8, 15, 15)]
    for (x0, y0, x1, y1) in blocos:
        base = pal[1] if rnd.random() > .3 else pal[2]
        rect(im, x0 + 1, y0 + 1, x1 - 1, y1 - 1, base)
        hl(im, x0 + 2, x1 - 2, y0 + 1, pal[0]); vl(im, x0 + 1, y0 + 2, y1 - 2, pal[0])
        hl(im, x0 + 2, x1 - 1, y1 - 1, pal[3]); vl(im, x1 - 1, y0 + 2, y1 - 1, pal[3])
        P(im, x0 + 1, y0 + 1, pal[4]); P(im, x1 - 1, y0 + 1, pal[4]); P(im, x0 + 1, y1 - 1, pal[4]); P(im, x1 - 1, y1 - 1, pal[4])
        if rnd.random() < .3: P(im, rnd.randint(x0 + 3, x1 - 3), rnd.randint(y0 + 3, y1 - 3), pal[2] if base == pal[1] else pal[3])
    return im

def tabuado(seed):
    im = new(); rnd = random.Random(20 + seed)
    for p in range(4):
        y0 = p * 4; base = MAD[1] if (p + seed) % 2 else MAD[2]
        rect(im, 0, y0, 15, y0 + 3, base); hl(im, 0, 15, y0, sh(base, 1.12)); hl(im, 0, 15, y0 + 3, MAD[4])
        j = rnd.randint(2, 13)
        if rnd.random() < .6: vl(im, j, y0, y0 + 2, MAD[4]); P(im, j + 2, y0 + 1, MAD[3])
    return im

def cascalho(seed):
    im = new(); rnd = random.Random(30 + seed); rect(im, 0, 0, 15, 15, TERRA[2])
    for _ in range(9):
        x, y = rnd.randint(0, 14), rnd.randint(0, 14); w = rnd.randint(1, 2)
        rect(im, x, y, x + w, y + 1, TERRA[1]); hl(im, x, x + w, y, TERRA[0]); hl(im, x, x + w, y + 2, TERRA[3])
    return im

def grama(seed, flores=False, borda=None):
    im = new(); rnd = random.Random(40 + seed); rect(im, 0, 0, 15, 15, GRA[2])
    for _ in range(5):
        x, y = rnd.randint(0, 15), rnd.randint(0, 15); hl(im, x, x + rnd.randint(2, 4), y, GRA[1])
    for _ in range(4):
        x, y = rnd.randint(1, 14), rnd.randint(2, 14)
        P(im, x, y - 1, GRA[0]); P(im, x - 1, y, GRA[1]); P(im, x + 1, y, GRA[1]); P(im, x, y, GRA[0]); hl(im, x - 1, x + 1, y + 1, GRA[3])
    if flores:
        for (x, y, c) in ((4, 5, CRE[0]), (11, 10, FOGO[0]), (8, 13, ROX[0])):
            P(im, x, y - 1, c); P(im, x - 1, y, c); P(im, x + 1, y, c); P(im, x, y + 1, c); P(im, x, y, FOGO[1])
    if borda == 'sombra':
        for y in range(5):
            for x in range(T): P(im, x, y, GRA[4] if y < 2 else GRA[3])
    return im

def gelo(seed):
    pal = [(236, 246, 255), (200, 224, 244), (170, 198, 228), (136, 162, 200), (104, 124, 168)]
    im = lajota(pal, seed)
    for (x, y) in ((3, 4), (12, 11)): P(im, x, y, (255, 255, 255))
    return im

# ---------- paredes de pedra azul ----------
def parede(linha, variante=None, seed=0):
    """linha 0 = topo (com sombra do teto), 1 = base (com rodape). Pedras grandes como no test_room."""
    im = new(); rnd = random.Random(60 + seed + linha * 7)
    rect(im, 0, 0, 15, 15, PED[4])
    for row in range(3):
        y0 = row * 5 + (1 if linha == 0 else 0); off = 4 if (row + linha) % 2 else 0
        for b in range(-1, 3):
            x0 = b * 8 + off
            if y0 + 3 > 15: continue
            base = PED[2] if rnd.random() > .25 else PED[3]
            for y in range(y0, y0 + 4):
                for x in range(x0 + 1, x0 + 8):
                    if 0 <= x < T:
                        c = base
                        if y == y0: c = PED[1]
                        if y == y0 + 3: c = PED[4]
                        if x == x0 + 7: c = PED[4]
                        P(im, x, y, c)
            if 0 <= x0 + 2 < T: P(im, x0 + 2, y0 + 1, PED[0])
    if linha == 0:
        hl(im, 0, 15, 0, PED[5])
        for x in range(T): P(im, x, 1, sh(G(im, x, 1), .75)); P(im, x, 2, sh(G(im, x, 2), .88))
    else:
        hl(im, 0, 15, 13, PED[1]); hl(im, 0, 15, 14, PED[3]); hl(im, 0, 15, 15, O)
    if variante == 'rachada':
        for (x, y) in ((9, 2), (9, 3), (10, 4), (10, 5), (11, 6), (10, 7), (11, 8), (12, 9)): P(im, x, y, PED[5])
    if variante == 'ralo':
        rect(im, 4, 4, 11, 12, PED[4]); ell(im, 7.5, 5, 4, 2.5, PED[4]); rect(im, 5, 5, 10, 12, (24, 20, 30))
        for x in (6, 8, 10): vl(im, x, 5, 12, PED[2])
        hl(im, 4, 11, 12, PED[1])
    if variante == 'musgo':
        for x in range(T):
            h = 2 + int(2 * (1 + math.sin(x * .9 + seed)))
            for y in range(13 - h, 13): P(im, x, y, VERDE[1] if y > 13 - h else VERDE[0])
    return im

def borda(tipo):
    """contorno de pedra das salas (como no test_room): 'e' 'd' 'b' 'be' 'bd' 'fim_e' 'fim_d'"""
    im = new()
    def vert(x0):
        rect(im, x0, 0, x0 + 3, 15, PED[2]); vl(im, x0, 0, 15, O); vl(im, x0 + 3, 0, 15, O); vl(im, x0 + 1, 0, 15, PED[1])
        for y in (4, 10): hl(im, x0 + 1, x0 + 2, y, PED[4])
    def horiz():
        rect(im, 0, 10, 15, 15, PED[2]); hl(im, 0, 15, 9, O); hl(im, 0, 15, 10, PED[0]); hl(im, 0, 15, 11, PED[1])
        for x in (5, 11): vl(im, x, 11, 14, PED[4])
        hl(im, 0, 15, 15, O)
    if tipo == 'e': vert(0)
    if tipo == 'd': vert(12)
    if tipo == 'b': horiz()
    if tipo == 'be': horiz(); vert(0); rect(im, 1, 10, 2, 14, PED[1])
    if tipo == 'bd': horiz(); vert(12); rect(im, 13, 10, 14, 14, PED[2])
    if tipo in ('fim_e', 'fim_d'):
        vert(0 if tipo == 'fim_e' else 12); x0 = 0 if tipo == 'fim_e' else 12
        for y in range(12, 16): hl(im, 0, 15, y, (0, 0, 0, 0)) if False else None
        im2 = new(); im2.alpha_composite(im.crop((0, 0, 16, 12)), (0, 0)); im = im2
        rect(im, x0, 11, x0 + 3, 13, PED[1]); hl(im, x0, x0 + 3, 14, O); hl(im, x0, x0 + 3, 11, PED[0])
    return im

def porta(parte=0):  # porta de madeira na parede (1x2)
    im = new(1, 2)
    rect(im, 1, 1, 14, 31, PED[3]); rect(im, 3, 3, 12, 31, MAD[3])
    rect(im, 4, 4, 11, 31, MAD[2])
    for x in (6, 9): vl(im, x, 4, 31, MAD[3])
    for y in (9, 24): hl(im, 4, 11, y, (90, 90, 100)); P(im, 4, y, (140, 140, 150))
    P(im, 10, 17, FOGO[0]); P(im, 10, 18, FOGO[1])
    ell(im, 7.5, 3, 6, 3, PED[3], 'top'); ell(im, 7.5, 4, 4.5, 2, MAD[3], 'top')
    return outline(im)

def janela_parede():
    im = new(1, 2)
    rect(im, 2, 4, 13, 22, PED[1]); ell(im, 7.5, 5, 5.5, 4, PED[1], 'top')
    rect(im, 4, 6, 11, 20, ROX[4]); ell(im, 7.5, 6, 3.6, 2.8, ROX[4], 'top'); rect(im, 4, 14, 11, 20, ROX[3])
    vl(im, 7, 4, 20, PED[3]); vl(im, 8, 4, 20, PED[3]); hl(im, 4, 11, 12, PED[3])
    for (x, y) in ((5, 8), (10, 16), (5, 17)): P(im, x, y, CRE[0])
    rect(im, 1, 21, 14, 23, CRE[2]); hl(im, 1, 14, 21, CRE[0])
    return outline(im)

# ---------- balcao / bancada ----------
def balcao(parte, lado='m'):
    im = new(); L, R = lado == 'e', lado == 'd'
    if parte == 0:   # tampo de madeira
        for y in range(T):
            c = MAD[0] if y in (1, 2) else (MAD[1] if y < 12 else (MAD[2] if y < 14 else MAD[3]))
            hl(im, 0, 15, y, c)
        hl(im, 0, 15, 0, O); hl(im, 0, 15, 6, MAD[2]); hl(im, 0, 15, 11, MAD[0]); hl(im, 0, 15, 15, O)
        P(im, 4, 3, MAD[2]); P(im, 12, 8, MAD[2])
    else:            # frente de pedra (como o murinho do test_room)
        rect(im, 0, 0, 15, 15, TER[3]); hl(im, 0, 15, 0, TER[4])
        for (x0, y0, x1, y1) in ((1, 2, 7, 8), (9, 2, 14, 8), (3, 9, 11, 12)):
            rect(im, x0, y0, x1, y1, TER[2]); hl(im, x0, x1, y0, TER[1]); hl(im, x0, x1, y1, TER[4])
        hl(im, 0, 15, 13, TER[4]); hl(im, 0, 15, 14, (60, 30, 30)); hl(im, 0, 15, 15, O)
    if L: vl(im, 0, 0, 15, O)
    if R: vl(im, 15, 0, 15, O)
    return im

# ---------- objetos (redesenhados do test_room + novos) ----------
def queijo():
    im = new(); d = ImageDraw.Draw(im)
    d.polygon([(2, 11), (13, 6), (14, 11)], fill=FOGO[0]); d.polygon([(2, 11), (14, 11), (14, 13), (2, 13)], fill=FOGO[1])
    for (x, y) in ((7, 11), (11, 12), (10, 9)): P(im, x, y, FOGO[2])
    return outline(im)
def barril():
    im = new()
    for y in range(2, 15):
        w = 5 + (1 if 4 < y < 12 else 0)
        for x in range(8 - w, 8 + w): P(im, x, y, MAD[1] if x < 6 else (MAD[3] if x > 10 else MAD[2]))
    for y in (4, 11): hl(im, 2, 13, y, PED[3]); hl(im, 3, 12, y - 1, PED[1]) if False else None
    ell(im, 8, 3, 5, 1.6, MAD[1]); ell(im, 8, 3, 3.5, 1, MAD[3])
    return outline(im)
def estante():
    im = new(1, 2); rect(im, 1, 1, 14, 30, MAD[3]); rect(im, 1, 1, 14, 2, MAD[2])
    for y0 in (3, 12, 21):
        rect(im, 2, y0, 13, y0 + 7, (50, 34, 40)); hl(im, 2, 13, y0 + 8, MAD[2])
        x = 2; rnd = random.Random(y0)
        while x < 13:
            w = rnd.choice((1, 2)); h = rnd.randint(4, 7); c = rnd.choice([VERM[1], VERDE[1], ROX[2], FOGO[1], PED[2]])
            rect(im, x, y0 + 8 - h, x + w - 1, y0 + 7, c); P(im, x, y0 + 8 - h, sh(c, 1.3)); x += w + rnd.choice((0, 1))
    return outline(im)
def estandarte(pal):
    im = new(); hl(im, 1, 14, 1, MAD[3]); hl(im, 1, 14, 0, MAD[2])
    rect(im, 3, 2, 12, 12, pal[1]); vl(im, 3, 2, 12, pal[0]); vl(im, 12, 2, 12, pal[2])
    ImageDraw.Draw(im).polygon([(3, 12), (7, 15), (8, 15), (12, 12)], fill=pal[1])
    ps = pts([".###.", "#.#.#", "#####", ".#.#."], 5, 5)
    for p in ps: P(im, *p, CRE[0])
    return outline(im)
def chave():
    im = new(); ell(im, 4.5, 8, 3.2, 3.2, FOGO[1]); ell(im, 4.5, 8, 1.6, 1.6, (0, 0, 0, 0)) if False else P(im, 4, 7, O)
    rect(im, 4, 7, 13, 8, FOGO[1]); hl(im, 7, 13, 7, FOGO[0]); rect(im, 11, 9, 11, 10, FOGO[2]); rect(im, 13, 9, 13, 11, FOGO[2])
    return outline(im)
def pocao(c):
    im = new(); ell(im, 8, 10, 4.5, 4.5, CRE[1]); ell(im, 8, 11, 3.5, 3, c[1]); P(im, 6, 10, c[0]); P(im, 6, 9, CRE[0])
    rect(im, 6, 3, 9, 5, CRE[1]); rect(im, 6, 2, 9, 2, MAD[2])
    return outline(im)
def mesa_pratos():
    im = new(2, 1)
    rect(im, 1, 3, 30, 10, MAD[1]); hl(im, 1, 30, 3, MAD[0]); hl(im, 1, 30, 10, MAD[3])
    rect(im, 1, 4, 30, 6, VERDE[1]); hl(im, 1, 30, 4, VERDE[0]); rect(im, 1, 7, 30, 7, VERM[1])
    for x in (7, 16, 25): ell(im, x, 5.5, 3, 1.6, CRE[0]); P(im, x, 5, CRE[2])
    rect(im, 2, 11, 29, 12, MAD[3])
    for x in (3, 28): vl(im, x, 12, 15, MAD[4])
    return outline(im)
def esqueleto():
    im = new(); d = ImageDraw.Draw(im)
    for (a, b) in (((2, 0), (5, 5)), ((13, 0), (10, 5))): d.line([a, b], fill=PED[2])
    rect(im, 6, 2, 9, 5, CRE[0]); P(im, 7, 3, O); P(im, 8, 3, O)
    vl(im, 7, 6, 11, CRE[1]); vl(im, 8, 6, 11, CRE[1])
    for y in (7, 9): hl(im, 5, 10, y, CRE[1])
    hl(im, 4, 6, 5, CRE[1]); hl(im, 9, 11, 5, CRE[1]); vl(im, 6, 12, 15, CRE[1]); vl(im, 9, 12, 15, CRE[1])
    return outline(im)
def bau():
    im = new(); rect(im, 1, 5, 14, 14, VERM[1]); rect(im, 1, 5, 14, 8, VERM[0]); hl(im, 1, 14, 9, MAD[3])
    for x in (3, 12): vl(im, x, 5, 14, FOGO[2])
    rect(im, 6, 8, 9, 11, FOGO[0]); P(im, 7, 10, O); hl(im, 1, 14, 14, VERM[2])
    return outline(im)
def alcapao():
    im = new(); rect(im, 1, 1, 14, 14, PED[3]); rect(im, 3, 3, 12, 12, (30, 26, 36)); hl(im, 1, 14, 1, PED[1]); vl(im, 1, 1, 14, PED[1])
    for x in (5, 8, 11): vl(im, x, 3, 12, PED[2])
    return outline(im)
def tocha():
    im = new(); rect(im, 7, 8, 8, 13, MAD[3]); hl(im, 6, 9, 13, PED[3])
    ell(im, 7.5, 5, 2.5, 3.5, ROX[2]); ell(im, 7.5, 6, 1.5, 2, ROX[0]); P(im, 7, 1, ROX[1])
    out = outline(im)
    for y in range(T):
        for x in range(T):
            dd = math.hypot(x - 7.5, y - 5)
            if dd < 8 and out.getpixel((x, y))[3] == 0: blend(out, x, y, ROX[1], .2 * (1 - dd / 8))
    return out
def caixote():
    im = new(); rect(im, 1, 2, 14, 14, MAD[2]); rect(im, 1, 2, 14, 3, MAD[0]); vl(im, 1, 2, 14, MAD[1])
    for i in range(11): P(im, 2 + i, 4 + i * 10 // 11, MAD[4])
    hl(im, 1, 14, 8, MAD[3]); hl(im, 1, 14, 14, MAD[4])
    return outline(im)
def sacos():
    im = new()
    for (cx, w) in ((6, 5), (11, 4)):
        for y in range(5, 15):
            ww = w if y > 7 else w - (7 - y)
            for x in range(cx - ww, cx + ww): P(im, x, y, CRE[2] if x < cx - 1 else CRE[3])
        hl(im, cx - w + 1, cx + w - 2, 10, MAD[2])
    return outline(im)
def lenha():
    im = new()
    for (x, y) in ((2, 10), (7, 10), (12, 10), (4, 6), (9, 6), (6.5, 2)):
        ell(im, x + 1.5, y + 2, 2.5, 2.4, MAD[2]); ell(im, x + 1.5, y + 2, 1.4, 1.3, MAD[0]); P(im, int(x + 1), int(y + 2), MAD[3])
    return outline(im)
def vaso():
    im = new()
    for y in range(9, 15):
        w = 4 - (y - 9) // 3
        for x in range(8 - w, 8 + w): P(im, x, y, TER[1] if x < 7 else TER[2])
    hl(im, 3, 12, 9, TER[0])
    for (bx, h, l) in ((5, 7, -1), (7, 9, 0), (9, 8, 1), (11, 6, 1)):
        for i in range(h): P(im, bx + (l * i) // 5, 8 - i, VERDE[0] if i % 3 else VERDE[1])
    return outline(im)
def cogumelinhos():
    im = new()
    for (x, y, r) in ((5, 14, 3), (11, 13, 2)):
        top = y - r - 1; rect(im, x - 1, top, x, y, CRE[0]); vl(im, x, top, y, CRE[2])
        for yy in range(top - r - 1, top + 1):
            for xx in range(x - r - 2, x + r + 2):
                if ((xx + .5 - x) / (r + .6)) ** 2 + ((yy + .5 - top - .5) / (r + 1.2)) ** 2 <= 1: P(im, xx, yy, ROX[1] if xx < x else ROX[2])
        hl(im, x - r, x + r - 1, top, ROX[3]); P(im, x - 2, top - r + 1, (230, 236, 160))
    return outline(im)
def caveira():
    im = new(); ps = pts(["..####..", ".######.", "########", "########", ".######.", "..#..#.."], 4, 6)
    for p in ps: P(im, *p, CRE[0])
    for (x, y) in ((5, 8), (6, 8), (5, 9), (9, 8), (10, 8), (10, 9), (7, 10)): P(im, x, y, (89, 86, 82))
    hl(im, 5, 10, 11, CRE[2]); return outline(im)
def teia():
    im = new(); d = ImageDraw.Draw(im)
    for a in (0, 30, 60, 90): d.line([(0, 0), (round(15 * math.cos(math.radians(a))), round(15 * math.sin(math.radians(a))))], fill=CRE[0] + (190,))
    for rr in (5, 10): d.line([(round(rr * math.cos(math.radians(a))), round(rr * math.sin(math.radians(a)))) for a in (0, 30, 60, 90)], fill=CRE[1] + (150,))
    return im
def banquinho():
    im = new(); ell(im, 8, 7, 5, 2.5, VERM[1]); ell(im, 7, 6, 3.5, 1.5, VERM[0])
    for x in (5, 10): vl(im, x, 9, 14, MAD[3])
    hl(im, 5, 10, 12, MAD[3]); return outline(im)
def placa():
    F = {'L': ["#..", "#..", "#..", "#..", "###"], 'O': [".#.", "#.#", "#.#", "#.#", ".#."], 'T': ["###", ".#.", ".#.", ".#.", ".#."],
         'U': ["#.#", "#.#", "#.#", "#.#", "###"], 'N': ["##.", "#.#", "#.#", "#.#", "#.#"], 'C': [".##", "#..", "#..", "#..", ".##"], 'H': ["#.#", "#.#", "###", "#.#", "#.#"]}
    im = new(2, 1); rect(im, 1, 1, 30, 14, MAD[2]); rect(im, 2, 2, 29, 13, MAD[1]); hl(im, 2, 29, 2, MAD[0])
    for i, ch in enumerate("LOOT"): [P(im, *p, MAD[4]) for p in pts(F[ch], 8 + i * 4, 3)]
    for i, ch in enumerate("LUNCH"): [P(im, *p, ROX[3]) for p in pts(F[ch], 6 + i * 4, 9)]
    return outline(im)
def lixeira():
    im = new(); rect(im, 3, 4, 12, 14, PED[2]); vl(im, 4, 4, 14, PED[1]); vl(im, 11, 4, 14, PED[3]); hl(im, 3, 12, 9, PED[3])
    rect(im, 2, 2, 13, 3, PED[1]); hl(im, 6, 9, 1, PED[3]); return outline(im)
def lanterna():
    im = new(1, 2); vl(im, 7, 10, 30, MAD[3]); vl(im, 8, 10, 30, MAD[4]); rect(im, 5, 29, 10, 31, MAD[4])
    rect(im, 5, 3, 10, 9, PED[3]); rect(im, 6, 4, 9, 8, FOGO[0]); hl(im, 4, 11, 2, PED[3]); hl(im, 6, 9, 1, PED[3])
    out = outline(im)
    for y in range(18):
        for x in range(T):
            dd = math.hypot(x - 7.5, y - 6)
            if dd < 8 and out.getpixel((x, y))[3] == 0: blend(out, x, y, FOGO[0], .22 * (1 - dd / 8))
    return out
def cerca(tipo='h'):
    im = new()
    if tipo == 'h':
        for x in (2, 13): rect(im, x, 3, x + 1, 14, MAD[2]); P(im, x, 3, MAD[0])
        hl(im, 0, 15, 6, MAD[1]); hl(im, 0, 15, 7, MAD[3]); hl(im, 0, 15, 10, MAD[1]); hl(im, 0, 15, 11, MAD[3])
    else:
        rect(im, 7, 0, 8, 15, MAD[2]); vl(im, 7, 0, 15, MAD[1])
        for y in (2, 10): rect(im, 6, y, 9, y + 2, MAD[3])
    return outline(im)
def pedra_pisar():
    im = new(2, 1)
    for (cx, r) in ((8, 6), (23, 6)):
        ell(im, cx, 8, r, 4, PED[2]); ell(im, cx - .5, 7, r - 1, 3, PED[1]); P(im, cx - 2, 6, PED[0])
    return outline(im)
def tapete():
    im = new(3, 2); rect(im, 1, 2, 46, 29, VERM[1]); rect(im, 4, 5, 43, 26, VERM[2]); rect(im, 6, 7, 41, 24, VERM[1])
    for x in range(10, 40, 6): ell(im, x, 15.5, 2, 2, FOGO[0])
    for x in range(1, 47, 2): P(im, x, 1, CRE[1]); P(im, x, 30, CRE[1])
    return outline(im)
def potes():
    im = new(2, 1)
    rect(im, 0, 11, 31, 12, MAD[1]); hl(im, 0, 31, 11, MAD[0]); hl(im, 0, 31, 13, MAD[3])
    for (x, c, h) in ((2, VERDE, 7), (8, VERM, 5), (13, FOGO, 8), (19, ROX, 6), (25, PED, 7)):
        rect(im, x, 11 - h, x + 4, 10, CRE[1]); rect(im, x + 1, 12 - h, x + 3, 9, c[1]); hl(im, x, x + 4, 10 - h, MAD[2])
    return outline(im)
def carne_gancho():
    im = new(1, 2); vl(im, 8, 0, 6, PED[2]); ell(im, 8, 16, 4, 7, VERM[1]); ell(im, 7, 14, 2, 4, VERM[0]); rect(im, 7, 23, 9, 25, CRE[0])
    return outline(im)
