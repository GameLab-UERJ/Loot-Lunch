from PIL import Image, ImageDraw
import random, math
T = 16
def new(w=1, h=1): return Image.new('RGBA', (w * T, h * T), (0, 0, 0, 0))
def C(c): return (int(c[0]), int(c[1]), int(c[2]), 255 if len(c) == 3 else int(c[3]))
def P(im, x, y, c):
    if 0 <= x < im.width and 0 <= y < im.height: im.putpixel((x, y), C(c))
def G(im, x, y): return im.getpixel((x, y))
def rect(im, x0, y0, x1, y1, c):
    for y in range(max(0, y0), min(im.height - 1, y1) + 1):
        for x in range(max(0, x0), min(im.width - 1, x1) + 1): im.putpixel((x, y), C(c))
def hl(im, x0, x1, y, c): rect(im, x0, y, x1, y, c)
def vl(im, x, y0, y1, c): rect(im, x, y0, x, y1, c)
def sh(c, k): return tuple(max(0, min(255, int(v * k))) for v in c[:3])
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
def blend(im, x, y, c, a):
    if not (0 <= x < im.width and 0 <= y < im.height): return
    o = im.getpixel((x, y))
    if o[3] == 0: im.putpixel((x, y), (c[0], c[1], c[2], int(255 * a))); return
    oa = o[3] / 255; na = a + oa * (1 - a)
    r = [int((c[i] * a + o[i] * oa * (1 - a)) / na) for i in range(3)]
    im.putpixel((x, y), (r[0], r[1], r[2], int(na * 255)))
def ell(im, cx, cy, rx, ry, c, half=None):
    for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
        for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
            if ((x + .5 - cx) / rx) ** 2 + ((y + .5 - cy) / ry) ** 2 <= 1:
                if half == 'top' and y + .5 > cy: continue
                P(im, x, y, c)
def outline(im, col=None):
    col = col or OUT
    src = im.copy(); w, h = im.size
    for y in range(h):
        for x in range(w):
            if src.getpixel((x, y))[3] > 200: continue
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                xx, yy = x + dx, y + dy
                if 0 <= xx < w and 0 <= yy < h and src.getpixel((xx, yy))[3] > 200:
                    im.putpixel((x, y), C(col)); break
    return im
def pts(rows, ox, oy): return [(ox + i, oy + j) for j, r in enumerate(rows) for i, ch in enumerate(r) if ch == '#']

# ---------- paleta (amostrada das artes do projeto) ----------
OUT = (43, 29, 14)
FL = [(222, 164, 110), (206, 146, 94), (188, 128, 80), (166, 110, 68), (142, 90, 56), (118, 74, 50), (104, 64, 42)]
BR = dict(hi=(240, 166, 118), a=(214, 124, 84), b=(198, 110, 74), lo=(166, 88, 62), mortar=(112, 82, 74), sombra=(70, 30, 24))
LB = [(156, 88, 60), (130, 72, 52), (104, 54, 42), (80, 40, 34), (58, 27, 26)]
CEIL = [(64, 46, 58), (52, 36, 46), (42, 28, 36)]
MAR = [(248, 244, 236), (234, 230, 222), (212, 206, 198), (186, 180, 174)]
GOLD = [(244, 206, 90), (232, 186, 52), (196, 146, 36)]
ST = [(178, 184, 196), (140, 146, 158), (106, 112, 124), (74, 78, 88), (48, 50, 60)]
RUST = [(190, 100, 62), (150, 70, 50)]
TB = [(240, 206, 150), (222, 180, 128), (206, 160, 110), (188, 132, 88), (166, 110, 68), (142, 90, 56), (118, 74, 50)]
PU = [(214, 196, 255), (166, 128, 246), (122, 82, 214), (84, 50, 150), (48, 26, 86)]
GR = [(176, 212, 112), (140, 188, 90), (112, 162, 76), (86, 132, 66), (62, 100, 58), (44, 74, 50)]
GRS = [(194, 196, 120), (164, 170, 98), (136, 144, 84), (108, 118, 72), (82, 92, 62), (60, 70, 52)]
CR = [(248, 244, 236), (226, 216, 204), (192, 178, 162), (146, 132, 124)]
BG = (12, 8, 14)
