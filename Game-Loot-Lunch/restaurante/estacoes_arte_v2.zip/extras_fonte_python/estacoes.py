from tr2 import *
FW = 32
def fr(h=32): return Image.new('RGBA', (FW, h), (0, 0, 0, 0))
GLOW = (214, 180, 255); GLOW2 = (240, 222, 255)
CAP = [(214, 170, 255), (172, 120, 240), (132, 82, 214), (98, 54, 172), (66, 32, 120)]
HASTE = [(246, 238, 255), (222, 208, 242), (188, 170, 214), (150, 130, 180)]
TERRA_R = [(112, 82, 96), (86, 60, 76), (62, 42, 58)]

def halo(im, cx, cy, r, cor, a):
    for y in range(im.height):
        for x in range(im.width):
            d = math.hypot(x + .5 - cx, (y + .5 - cy) * 1.15)
            if d < r: blend(im, x, y, cor, a * (1 - d / r) ** 1.4)

def particula(im, x, y, tam=1, cor=GLOW2):
    x, y = int(x), int(y)
    P(im, x, y, cor)
    if tam > 1:
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)): P(im, x + dx, y + dy, GLOW)

# ================= COGUMELO (32 x 40, chao em y 37) =================
FH = 40; OY = 8
def cap_img(s, squash=0, brilho=.5):
    """chapeu do cogumelo fantasia: sino roxo com borda caida, lamelas e pintas que brilham"""
    tmp = Image.new('RGBA', (FW, FH), (0, 0, 0, 0))
    cx, cy = 16, 15 + OY + squash
    rx, ry = 13 * s, (9 - squash * .7) * s
    if rx < 1.5: return tmp
    for y in range(int(cy - ry) - 1, int(cy + 3 * s) + 2):
        for x in range(int(cx - rx) - 2, int(cx + rx) + 3):
            u = (x + .5 - cx) / rx; v = (y + .5 - cy) / ry
            dentro = (u * u + v * v <= 1 and v <= 0) or (abs(u) <= 1 and 0 < v <= .35 * (1 - u * u) + .05 and s > .3)
            if not dentro: continue
            c = CAP[2]
            if u < -.2 and v < -.25: c = CAP[1]
            if u < -.4 and v < -.55: c = CAP[0]
            if u > .45: c = CAP[3]
            if v > -.05: c = CAP[3]
            if v > .12: c = CAP[4]
            P(tmp, x, y, c)
    # lamelas embaixo
    if s > .4:
        for x in range(int(cx - rx * .7), int(cx + rx * .7) + 1, 2): P(tmp, x, int(cy + 1), CAP[4]); P(tmp, x, int(cy + 2 * s), (60, 28, 104))
    # pintas que brilham
    for (fx, fy, r) in ((-.5, -.5, 1.8), (.1, -.72, 1.4), (.52, -.35, 1.6), (-.12, -.25, 1.1), (-.78, -.12, .9), (.75, -.05, .8)):
        if s < .5 and r < 1.7: continue
        if s < .3: continue
        px_, py_ = cx + fx * rx, cy + fy * ry
        ell(tmp, px_, py_, r * s + .4, r * s + .3, GLOW if brilho < .6 else GLOW2)
        P(tmp, int(px_), int(py_), (255, 255, 255) if brilho > .3 else GLOW2)
    outline(tmp, O)
    # brilho em volta das pintas
    out = Image.new('RGBA', (FW, FH), (0, 0, 0, 0))
    halo(out, cx, cy - ry * .5, rx + 5, GLOW, .22 + .2 * brilho)
    out.alpha_composite(tmp)
    return out

def cogumelo_desenho(escala=1.0, brilho=.5, dy=0, cortado=False, tampa_off=None, squash=0):
    im = Image.new('RGBA', (FW, FH), (0, 0, 0, 0))
    halo(im, 16, 30, 13, GLOW, .14 + .1 * brilho)                       # luz no chao
    base = Image.new('RGBA', (FW, FH), (0, 0, 0, 0)); d = ImageDraw.Draw(base)
    ell(base, 16, 36, 9, 2.6, TERRA_R[1]); ell(base, 15, 35.5, 7, 1.6, TERRA_R[0])
    for pts_ in (((12, 35), (7, 37), (4, 38)), ((20, 35), (25, 37), (28, 38)), ((14, 36), (12, 39)), ((18, 36), (21, 39))):
        d.line(pts_, fill=CAP[3], width=1)
    for (x, y) in ((5, 38), (27, 38), (12, 39)): P(base, x, y, GLOW)
    topo = (14 + OY + dy + squash) if not cortado else 28
    for y in range(topo, 36):
        k = (y - topo) / max(1, 36 - topo)
        xc = 16 + int(1.2 * math.sin(k * 2.2))         # haste levemente curva
        w = 2 if k < .7 else 3
        for x in range(xc - w, xc + w):
            P(base, x, y, HASTE[0] if x < xc - 1 else (HASTE[2] if x >= xc + 1 else HASTE[1]))
    if not cortado:
        ry_ = 19 + OY + dy + squash // 2
        hl(base, 13, 19, ry_, HASTE[2]); hl(base, 14, 18, ry_ + 1, HASTE[3])
    else:
        hl(base, 14, 17, 28, GLOW2); hl(base, 14, 17, 29, GLOW); P(base, 18, 29, HASTE[2])
    outline(base, O); im.alpha_composite(base)
    if not cortado:
        c = cap_img(escala, squash, brilho)
        im.alpha_composite(c, (0, dy + int((1 - escala) * 6)))
    if tampa_off:
        dx_, dy_, al = tampa_off
        c = cap_img(1.0, 0, 1.0); c.putalpha(c.split()[3].point(lambda v: int(v * al))); im.alpha_composite(c, (dx_, dy_))
    return im

def esporos(im, i, n, raio=11, cy=12):
    for k in range(n):
        ang = i / 6 * 2 * math.pi + k * 2 * math.pi / n
        y = cy + OY - ((i * 2 + k * 5) % 12)
        particula(im, 16 + raio * math.cos(ang), y, 1, GLOW2 if (i + k) % 2 else GLOW)

def cogumelo_idle():
    frames = []
    for i in range(6):
        b = .5 + .5 * math.sin(i / 6 * 2 * math.pi)
        im = cogumelo_desenho(1.0, b, dy=-1 if i in (2, 3) else 0)
        esporos(im, i, 3); frames.append(im)
    return frames

def cogumelo_corte():
    frames = [cogumelo_desenho(1.0, 1.0, squash=2)]
    im = cogumelo_desenho(1.0, 1.0, squash=1); d = ImageDraw.Draw(im)
    d.line([(5, 27), (27, 24)], fill=(255, 255, 255, 255)); d.line([(6, 28), (26, 25)], fill=GLOW + (220,)); frames.append(im)
    for k, (dx_, dy_, al) in enumerate(((1, -2, 1), (3, -5, .85), (4, -8, .5), (5, -10, .2))):
        im = cogumelo_desenho(cortado=True, tampa_off=(dx_, dy_, al), brilho=.8)
        rnd = random.Random(k)
        for j in range(7 - k):
            ang = rnd.uniform(0, 2 * math.pi); r = 4 + k * 3
            particula(im, 16 + r * math.cos(ang), 26 + r * .6 * math.sin(ang) - k, 2 if j % 3 == 0 else 1)
        frames.append(im)
    frames.append(cogumelo_desenho(cortado=True, brilho=.2))
    return frames

def cogumelo_regen():
    frames = []
    escalas = [0, .2, .32, .46, .6, .74, .88, 1.0]
    for i, s_ in enumerate(escalas):
        im = cogumelo_desenho(cortado=True, brilho=i / 7) if s_ == 0 else cogumelo_desenho(s_, i / 7, dy=int((1 - s_) * 6))
        rnd = random.Random(10 + i)
        for j in range(3 + i // 2):
            ang = rnd.uniform(0, 2 * math.pi); r = rnd.uniform(3, 11)
            particula(im, 16 + r * math.cos(ang), 26 - i * 1.4 + r * .5 * math.sin(ang), 1)
        if i == len(escalas) - 1:
            halo(im, 16, 18, 16, GLOW2, .35)
            for ang in range(0, 360, 45): particula(im, 16 + 13 * math.cos(math.radians(ang)), 18 + 10 * math.sin(math.radians(ang)), 2)
        frames.append(im)
    return frames

# ================= RAIZ DE ESPETO (32 x 40) =================
TRONCO = [(196, 150, 110), (160, 112, 80), (124, 82, 60), (92, 58, 46), (66, 40, 36)]
ESPETO = [(244, 214, 160), (214, 174, 120), (172, 128, 86)]
RUNA = [(240, 222, 255), (196, 160, 255), (140, 100, 230)]
def espeto_img(top, base_y, alpha=1.0, brilho=.5):
    tmp = Image.new('RGBA', (FW, FH), (0, 0, 0, 0))
    if base_y - top < 1: return tmp
    top = int(top)
    for y in range(top, base_y):
        P(tmp, 15, y, ESPETO[0]); P(tmp, 16, y, ESPETO[1]); P(tmp, 17, y, ESPETO[2])
    P(tmp, 16, top - 1, ESPETO[1]); P(tmp, 16, top - 2, ESPETO[0])
    # trepadeira roxa em espiral
    for y in range(top + 2, base_y, 1):
        k = (y - top) * .8
        x = 16 + round(2.2 * math.sin(k))
        if x != 16: P(tmp, x, y, RUNA[2] if math.cos(k) > 0 else CAP[3])
    for (yy, side) in ((top + 5, -1), (top + 11, 1)):
        if yy < base_y - 2: P(tmp, 16 + side * 3, yy, RUNA[1]); P(tmp, 16 + side * 4, yy - 1, RUNA[0])
    outline(tmp, O)
    # broto brilhante na ponta
    if base_y - top > 6:
        halo(tmp, 16, top - 1, 5, RUNA[0], .35 + .25 * brilho); P(tmp, 16, top - 2, (255, 255, 255))
    if alpha < 1: tmp.putalpha(tmp.split()[3].point(lambda v: int(v * alpha)))
    return tmp

def raiz_desenho(altura=1.0, brilho=.5, quebrado=False, tampa=None, rachado=False):
    im = Image.new('RGBA', (FW, FH), (0, 0, 0, 0))
    halo(im, 16, 32, 12, RUNA[1], .16 + .16 * brilho)
    base = Image.new('RGBA', (FW, FH), (0, 0, 0, 0)); d = ImageDraw.Draw(base)
    for (pts_, w) in ((((10, 33), (5, 36), (1, 37)), 2), (((22, 33), (27, 36), (31, 37)), 2), (((13, 35), (9, 39)), 1), (((19, 35), (23, 39)), 1), (((16, 36), (16, 39)), 1)):
        d.line(pts_, fill=TRONCO[2], width=w); d.line([pts_[0], pts_[1]], fill=TRONCO[1], width=1)
    for y in range(26, 36):
        w = 6 if y < 33 else 7
        for x in range(16 - w, 16 + w): P(base, x, y, TRONCO[1] if x < 13 else (TRONCO[3] if x > 18 else TRONCO[2]))
    ell(base, 16, 26.5, 6, 2.2, TRONCO[1]); ell(base, 16, 26.5, 4.2, 1.3, TRONCO[0]); ell(base, 16, 26.5, 2, .6, TRONCO[1])
    cr = mix(RUNA[2], RUNA[0], brilho)
    for (x, y) in ((12, 29), (12, 30), (13, 31), (13, 32), (19, 30), (20, 31), (19, 32), (16, 33), (16, 34), (15, 29)): P(base, x, y, cr)
    # cogumelinhos roxos no toco
    for (x, y) in ((10, 27), (21, 28)):
        ell(base, x, y, 2, 1.3, CAP[1]); P(base, x - 1, y - 1, GLOW2); vl(base, x, y + 1, y + 2, HASTE[1])
    outline(base, O); im.alpha_composite(base)
    for (x, y) in ((1, 37), (31, 37), (9, 39), (23, 39)): P(im, x, y, cr)
    if not quebrado: im.alpha_composite(espeto_img(27 - 22 * altura, 27, 1, brilho))
    else: hl(im, 15, 17, 26, ESPETO[2]); P(im, 16, 25, ESPETO[1])
    if tampa:
        dy_, al = tampa; im.alpha_composite(espeto_img(5 + dy_, 26 + dy_, al, 1))
    if rachado:
        P(im, 15, 25, (255, 255, 255)); P(im, 17, 24, (255, 255, 255)); P(im, 14, 24, GLOW)
    return im

def raiz_idle():
    frames = []
    for i in range(6):
        b = .5 + .5 * math.sin(i / 6 * 2 * math.pi)
        im = raiz_desenho(1.0, b)
        for k in range(3):
            y = 36 - ((i * 3 + k * 7) % 22)
            particula(im, 7 + k * 9 + (i % 2), y, 1, RUNA[0] if k % 2 else RUNA[1])
        frames.append(im)
    return frames

def raiz_corte():
    frames = [raiz_desenho(1.0, 1.0, rachado=True)]
    im = raiz_desenho(1.0, 1.0, rachado=True); halo(im, 16, 26, 8, (255, 255, 255), .5); frames.append(im)
    for k, (dy_, al) in enumerate(((-2, 1), (-4, .8), (-6, .5), (-8, .2))):
        im = raiz_desenho(quebrado=True, brilho=.8, tampa=(dy_, al))
        rnd = random.Random(20 + k)
        for j in range(6 - k):
            x = 16 + rnd.uniform(-9, 9); y = 26 + rnd.uniform(-5, 4) + k
            P(im, int(x), int(y), ESPETO[1] if j % 2 else RUNA[0]); P(im, int(x) + 1, int(y), ESPETO[2] if j % 2 else RUNA[1])
        frames.append(im)
    frames.append(raiz_desenho(quebrado=True, brilho=.2))
    return frames

def raiz_regen():
    frames = []
    alturas = [0, .1, .22, .36, .5, .66, .82, 1.0]
    for i, h in enumerate(alturas):
        im = raiz_desenho(quebrado=True, brilho=i / 7) if h == 0 else raiz_desenho(h, i / 7)
        rnd = random.Random(30 + i)
        for j in range(2 + i // 2):
            ang = rnd.uniform(0, 2 * math.pi); r = rnd.uniform(4, 12)
            particula(im, 16 + r * math.cos(ang), 32 + r * .4 * math.sin(ang) - i * 1.2, 1, RUNA[0] if j % 2 else RUNA[1])
        if i == len(alturas) - 1:
            halo(im, 16, 18, 13, RUNA[0], .3)
            for ang in range(0, 360, 60): particula(im, 16 + 9 * math.cos(math.radians(ang)), 18 + 9 * math.sin(math.radians(ang)), 2, RUNA[0])
        frames.append(im)
    return frames

# ================= MESAS (estacoes estaticas) =================
def mesa_base():
    im = fr()
    # tampo
    rect(im, 1, 8, 30, 22, MAD[1]); hl(im, 1, 30, 8, MAD[0]); hl(im, 1, 30, 9, MAD[0])
    for y in (13, 18): hl(im, 2, 29, y, MAD[2])
    hl(im, 1, 30, 21, MAD[0]); hl(im, 1, 30, 22, MAD[2])
    # frente com gaveta
    rect(im, 1, 23, 30, 28, MAD[2]); hl(im, 1, 30, 23, MAD[3])
    rect(im, 9, 24, 22, 27, MAD[3]); hl(im, 9, 22, 24, MAD[4]); hl(im, 14, 17, 25, FOGO[1])
    for x in (2, 28): rect(im, x, 28, x + 1, 30, MAD[3])
    return im
def mesa_carne():
    im = mesa_base()
    # peca de carne grande com gordura e osso
    ell(im, 14, 15, 9, 5, VERM[1]); ell(im, 13, 14, 7.5, 3.8, VERM[0])
    for (x, y) in ((9, 14), (10, 13), (14, 12), (15, 13), (18, 15), (12, 16)): P(im, x, y, (244, 186, 186))
    hl(im, 7, 20, 19, VERM[2]); rect(im, 21, 13, 26, 14, CRE[0]); ell(im, 26.5, 13.5, 1.6, 1.8, CRE[0]); ell(im, 21, 13.5, 1.2, 1.4, CRE[1])
    # cutelo
    rect(im, 22, 16, 28, 19, PED[1]); hl(im, 22, 28, 16, PED[0]); rect(im, 28, 17, 30, 18, MAD[3])
    outline(im, O)
    return im
def mesa_corte():
    im = mesa_base()
    # tabua de corte embutida + faca + rodelas
    rect(im, 4, 10, 22, 20, (232, 196, 140)); hl(im, 4, 22, 10, (246, 220, 170)); hl(im, 4, 22, 20, (196, 156, 104)); vl(im, 22, 10, 20, (196, 156, 104))
    for (x, y) in ((8, 13), (14, 16), (18, 12)): P(im, x, y, (214, 176, 124))
    ell(im, 20.5, 6.5, 1.6, 1.6, (232, 196, 140)) if False else None
    rect(im, 24, 11, 28, 12, PED[0]); hl(im, 24, 28, 13, PED[2]); rect(im, 24, 14, 25, 18, MAD[3]); P(im, 24, 14, MAD[4])
    for (x, y, c) in ((8, 15, CAP[2]), (11, 15, CAP[1]), (17, 15, VERM[0])):
        ell(im, x, y, 1.8, 1.4, c); P(im, x - 1, y - 1, (255, 255, 255) if c != VERM[0] else (250, 200, 200))
    outline(im, O)
    return im

def strip(frames):
    w, h = frames[0].size
    s = Image.new('RGBA', (w * len(frames), h), (0, 0, 0, 0))
    for i, f in enumerate(frames): s.alpha_composite(f, (i * w, 0))
    return s
